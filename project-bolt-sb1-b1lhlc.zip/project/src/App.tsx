import React, { useEffect, useState } from 'react';
import { MapPin, Compass, X } from 'lucide-react';
import MapComponent from './components/Map';
import SearchBar from './components/SearchBar';
import LocationCard from './components/LocationCard';
import BookingForm from './components/BookingForm';
import FixedRoutes from './components/FixedRoutes';
import { calculateDistance } from './utils/distance';
import { fixedRoutes } from './data/fixedRoutes';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default marker icon issue
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface Location {
  position: [number, number];
  title: string;
  distance?: number;
  fixedPrice?: number;
}

function App() {
  const [currentLocation, setCurrentLocation] = useState<[number, number]>([51.505, -0.09]);
  const [markers, setMarkers] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [navigationPath, setNavigationPath] = useState<[number, number][]>();
  const [showBooking, setShowBooking] = useState(false);
  const [selectedDestination, setSelectedDestination] = useState<Location | null>(null);

  const updateDistances = (locations: Location[], currentPos: [number, number]) => {
    return locations.map(location => ({
      ...location,
      distance: calculateDistance(
        currentPos[0],
        currentPos[1],
        location.position[0],
        location.position[1]
      )
    }));
  };

  const getCurrentLocation = () => {
    if ('geolocation' in navigator) {
      setIsLoading(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const newLocation: [number, number] = [latitude, longitude];
          setCurrentLocation(newLocation);
          setMarkers(prev => updateDistances(
            [{ position: newLocation, title: 'You are here' }, ...prev.slice(1)],
            newLocation
          ));
          setIsLoading(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setIsLoading(false);
        }
      );
    } else {
      alert('Geolocation is not supported by your browser');
    }
  };

  const handleSearch = async (query: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`
      );
      const data = await response.json();
      
      if (data && data.length > 0) {
        const { lat, lon, display_name } = data[0];
        const newLocation: [number, number] = [parseFloat(lat), parseFloat(lon)];
        const newMarker = {
          position: newLocation,
          title: display_name
        };
        
        setMarkers(prev => {
          const updated = [...prev, newMarker];
          return updateDistances(updated, currentLocation);
        });
      }
    } catch (error) {
      console.error('Error searching location:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNavigate = (destination: [number, number]) => {
    setNavigationPath([currentLocation, destination]);
  };

  const handleSelectLocation = (position: [number, number]) => {
    setCurrentLocation(position);
    setNavigationPath(undefined);
  };

  const handleBook = (destination: Location) => {
    setSelectedDestination(destination);
    setShowBooking(true);
  };

  const handleFixedRoute = (from: [number, number], to: [number, number], price: number) => {
    const fromLocation = { position: from, title: fixedRoutes[0].from.title };
    const toLocation = { 
      position: to, 
      title: fixedRoutes[0].to.title,
      fixedPrice: price,
      distance: calculateDistance(from[0], from[1], to[0], to[1])
    };
    
    setMarkers([fromLocation, toLocation]);
    setCurrentLocation(from);
    setNavigationPath([from, to]);
    handleBook(toLocation);
  };

  const clearNavigation = () => {
    setNavigationPath(undefined);
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {showBooking && selectedDestination ? (
        <BookingForm
          origin={markers[0]?.title || 'Current Location'}
          destination={selectedDestination.title}
          distance={selectedDestination.distance}
          fixedPrice={selectedDestination.fixedPrice}
          onClose={() => {
            setShowBooking(false);
            setSelectedDestination(null);
          }}
        />
      ) : (
        <div className="p-8">
          <div className="max-w-6xl mx-auto space-y-8">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-gray-800 flex items-center justify-center gap-2">
                <MapPin className="h-8 w-8 text-blue-500" />
                Location Finder
              </h1>
              <p className="text-gray-600">Find and explore locations on the map</p>
            </div>

            <FixedRoutes onSelectRoute={handleFixedRoute} />

            <div className="flex justify-center space-x-4">
              <SearchBar onSearch={handleSearch} isLoading={isLoading} />
              <button
                onClick={getCurrentLocation}
                className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                disabled={isLoading}
              >
                <Compass className="h-5 w-5" />
                {isLoading ? 'Locating...' : 'Current Location'}
              </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg relative">
              <MapComponent
                center={currentLocation}
                markers={markers}
                navigationPath={navigationPath}
              />
              {navigationPath && (
                <button
                  onClick={clearNavigation}
                  className="absolute top-8 right-8 z-[1000] bg-white p-2 rounded-full shadow-md hover:bg-gray-100"
                  title="Clear navigation"
                >
                  <X className="h-5 w-5 text-gray-600" />
                </button>
              )}
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-semibold">Saved Locations</h2>
                <span className="text-sm text-gray-500">
                  {markers.length} location{markers.length !== 1 ? 's' : ''}
                </span>
              </div>
              <div className="space-y-2">
                {markers.map((marker, index) => (
                  <LocationCard
                    key={index}
                    title={marker.title}
                    position={marker.position}
                    distance={marker.distance}
                    onNavigate={() => handleNavigate(marker.position)}
                    onSelect={() => handleSelectLocation(marker.position)}
                    onBook={() => handleBook(marker)}
                    showBooking={index !== 0}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;