export interface FixedRoute {
  id: string;
  from: {
    title: string;
    position: [number, number];
  };
  to: {
    title: string;
    position: [number, number];
  };
  price: number;
}

export const fixedRoutes: FixedRoute[] = [
  {
    id: 'gpc-sahatwar',
    from: {
      title: 'Government Polytechnic College Basdih',
      position: [25.8768, 84.1723]
    },
    to: {
      title: 'Sahatwar Station',
      position: [25.8501, 84.1896]
    },
    price: 25
  }
];