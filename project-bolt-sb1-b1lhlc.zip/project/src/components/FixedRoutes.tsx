import React from 'react';
import { MapPin, ArrowRight } from 'lucide-react';
import { fixedRoutes } from '../data/fixedRoutes';
import { formatDistance } from '../utils/distance';

interface FixedRoutesProps {
  onSelectRoute: (from: [number, number], to: [number, number], price: number) => void;
}

export default function FixedRoutes({ onSelectRoute }: FixedRoutesProps) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-semibold">Popular Routes</h2>
        <span className="text-sm text-gray-500">Fixed Price Routes</span>
      </div>
      <div className="space-y-3">
        {fixedRoutes.map((route) => (
          <div
            key={route.id}
            className="p-4 border border-gray-200 rounded-lg hover:border-blue-200 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-blue-500 flex-shrink-0 mt-1" />
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium text-gray-900">{route.from.title}</p>
                      <p className="text-sm text-gray-500">
                        {route.from.position[0].toFixed(4)}, {route.from.position[1].toFixed(4)}
                      </p>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{route.to.title}</p>
                      <p className="text-sm text-gray-500">
                        {route.to.position[0].toFixed(4)}, {route.to.position[1].toFixed(4)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <div className="text-right">
                  <p className="text-2xl font-bold text-blue-600">₹{route.price}</p>
                  <p className="text-sm text-gray-500">Fixed Price</p>
                </div>
                <button
                  onClick={() => onSelectRoute(route.from.position, route.to.position, route.price)}
                  className="flex items-center gap-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Book Now
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}