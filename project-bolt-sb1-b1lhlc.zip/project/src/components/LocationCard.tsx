import React from 'react';
import { MapPin, Navigation2, ArrowRight } from 'lucide-react';
import { formatDistance } from '../utils/distance';

interface LocationCardProps {
  title: string;
  position: [number, number];
  distance?: number;
  onNavigate: () => void;
  onSelect: () => void;
  onBook?: () => void;
  showBooking?: boolean;
}

export default function LocationCard({
  title,
  position,
  distance,
  onNavigate,
  onSelect,
  onBook,
  showBooking = false,
}: LocationCardProps) {
  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
      <div className="flex items-center gap-3 flex-1" onClick={onSelect} role="button">
        <MapPin className="h-5 w-5 text-blue-500 flex-shrink-0" />
        <div>
          <h3 className="font-medium text-gray-900">{title}</h3>
          <p className="text-sm text-gray-500">
            {position[0].toFixed(6)}, {position[1].toFixed(6)}
            {distance !== undefined && (
              <span className="ml-2 text-blue-600">({formatDistance(distance)})</span>
            )}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={onNavigate}
          className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
          title="Navigate to this location"
        >
          <Navigation2 className="h-5 w-5" />
        </button>
        {showBooking && onBook && (
          <button
            onClick={onBook}
            className="flex items-center gap-1 px-3 py-1 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Book
            <ArrowRight className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}