import React, { useState } from 'react';
import { Car, Bike, Truck, X } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BookingFormProps {
  origin: string;
  destination: string;
  distance?: number;
  onClose: () => void;
}

interface Vehicle {
  id: string;
  name: string;
  icon: React.ReactNode;
  pricePerKm: number;
}

const vehicles: Vehicle[] = [
  { id: 'car', name: 'Car', icon: <Car className="h-6 w-6" />, pricePerKm: 1.5 },
  { id: 'bike', name: 'Bike', icon: <Bike className="h-6 w-6" />, pricePerKm: 1.0 },
  { id: 'truck', name: 'Truck', icon: <Truck className="h-6 w-6" />, pricePerKm: 2.5 },
];

export default function BookingForm({ origin, destination, distance, onClose }: BookingFormProps) {
  const [selectedVehicle, setSelectedVehicle] = useState<string>('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Trigger confetti animation
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });

    // Reset form
    setSelectedVehicle('');
    setFormData({ name: '', email: '', phone: '' });
    
    // Close after animation
    setTimeout(onClose, 2000);
  };

  const estimatedPrice = distance && selectedVehicle
    ? (vehicles.find(v => v.id === selectedVehicle)?.pricePerKm || 0) * distance
    : null;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Book Your Ride</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">From</p>
              <p className="font-medium">{origin}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">To</p>
              <p className="font-medium">{destination}</p>
            </div>
            {distance && (
              <div className="col-span-2">
                <p className="text-sm text-gray-500">Distance</p>
                <p className="font-medium">{distance.toFixed(2)} km</p>
              </div>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Select Vehicle
            </label>
            <div className="grid grid-cols-3 gap-4">
              {vehicles.map((vehicle) => (
                <button
                  key={vehicle.id}
                  type="button"
                  onClick={() => setSelectedVehicle(vehicle.id)}
                  className={`p-4 border rounded-lg flex flex-col items-center gap-2 transition-colors ${
                    selectedVehicle === vehicle.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-200'
                  }`}
                >
                  {vehicle.icon}
                  <span className="text-sm font-medium">{vehicle.name}</span>
                  <span className="text-xs text-gray-500">
                    ${vehicle.pricePerKm}/km
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Full Name
              </label>
              <input
                type="text"
                id="name"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                type="email"
                id="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                Phone Number
              </label>
              <input
                type="tel"
                id="phone"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          {estimatedPrice && (
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-600">Estimated Price</p>
              <p className="text-2xl font-bold text-blue-700">
                ${estimatedPrice.toFixed(2)}
              </p>
            </div>
          )}

          <button
            type="submit"
            disabled={!selectedVehicle}
            className="w-full py-3 px-4 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            Book Now
          </button>
        </form>
      </div>
    </div>
  );
}