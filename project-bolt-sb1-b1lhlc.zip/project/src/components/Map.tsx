import { MapContainer, TileLayer, Marker, Popup, useMap, Polyline, ZoomControl } from 'react-leaflet';
import { useEffect, useState } from 'react';
import { LatLngExpression, Icon } from 'leaflet';
import { formatDistance } from '../utils/distance';
import { MapPin } from 'lucide-react';

interface MapComponentProps {
  center: LatLngExpression;
  markers: Array<{
    position: LatLngExpression;
    title: string;
    distance?: number;
  }>;
  navigationPath?: LatLngExpression[];
}

// Custom marker icons
const createCustomIcon = (color: string) => new Icon({
  iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const currentLocationIcon = createCustomIcon('red');
const destinationIcon = createCustomIcon('blue');

function MapUpdater({ center }: { center: LatLngExpression }) {
  const map = useMap();
  
  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center, map]);
  
  return null;
}

export default function MapComponent({ center, markers, navigationPath }: MapComponentProps) {
  const [mapType, setMapType] = useState<'streets' | 'satellite'>('streets');
  
  const mapStyles = {
    streets: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
  };

  return (
    <div className="relative h-[500px] w-full">
      <MapContainer
        center={center}
        zoom={13}
        className="h-full w-full rounded-lg shadow-lg"
        zoomControl={false}
        style={{ height: '100%', width: '100%' }}
      >
        <MapUpdater center={center} />
        <ZoomControl position="bottomright" />
        
        <TileLayer
          attribution={mapType === 'streets' ? 
            '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' :
            'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'}
          url={mapStyles[mapType]}
        />

        {markers.map((marker, index) => (
          <Marker 
            key={index} 
            position={marker.position}
            icon={index === 0 ? currentLocationIcon : destinationIcon}
          >
            <Popup className="custom-popup">
              <div className="text-center p-2">
                <h3 className="font-medium text-gray-900">{marker.title}</h3>
                {marker.distance !== undefined && (
                  <p className="text-sm text-gray-600 mt-1">
                    Distance: {formatDistance(marker.distance)}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  {typeof marker.position[0] === 'number' && 
                   typeof marker.position[1] === 'number' && (
                    <>
                      Lat: {marker.position[0].toFixed(6)}<br />
                      Lon: {marker.position[1].toFixed(6)}
                    </>
                  )}
                </p>
              </div>
            </Popup>
          </Marker>
        ))}

        {navigationPath && (
          <Polyline
            positions={navigationPath}
            color="#3b82f6"
            weight={3}
            opacity={0.7}
            dashArray="10"
          />
        )}
      </MapContainer>

      {/* Map Type Toggle */}
      <div className="absolute top-4 right-4 z-[1000] bg-white rounded-lg shadow-md">
        <button
          onClick={() => setMapType('streets')}
          className={`px-3 py-2 text-sm rounded-l-lg ${
            mapType === 'streets' 
              ? 'bg-blue-500 text-white' 
              : 'bg-white text-gray-700 hover:bg-gray-100'
          }`}
        >
          Streets
        </button>
        <button
          onClick={() => setMapType('satellite')}
          className={`px-3 py-2 text-sm rounded-r-lg ${
            mapType === 'satellite' 
              ? 'bg-blue-500 text-white' 
              : 'bg-white text-gray-700 hover:bg-gray-100'
          }`}
        >
          Satellite
        </button>
      </div>
    </div>
  );
}